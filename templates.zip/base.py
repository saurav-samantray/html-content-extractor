class BaseExtractor:
	def dummymethod():
		print("This is dummy method")